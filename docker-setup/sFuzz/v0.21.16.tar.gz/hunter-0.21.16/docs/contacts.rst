.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Contacts
--------

Public
======

* Feel free to open new `issue`_ if you want to ask any question
* Public chat room on |gitter_public|

Private
=======

* Write me to ruslan_baratov@yahoo.com
* Private chat room on |gitter_private|

.. _issue: https://github.com/ruslo/hunter/issues/new

.. |gitter_public| image:: https://badges.gitter.im/ruslo/hunter.svg
  :target: https://gitter.im/ruslo/hunter

.. |gitter_private| image:: https://badges.gitter.im/ruslo/hunter.svg
  :target: https://gitter.im/ruslo
