.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Internal variables
------------------

.. toctree::
  :glob:
  :maxdepth: 1

  /reference/internal-variables/*
