Containers
----------

 * :ref:`pkg.sparsehash` - C++ associative containers
 * :ref:`pkg.sds` - Simple Dynamic Strings library for C
