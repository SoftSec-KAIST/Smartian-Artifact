.. spelling::

  autotools

CMake Modules
-------------

 - :ref:`pkg.autoutils` - CMake utilities to imitate autotools functions
 - :ref:`pkg.Sugar` - CMake tools and examples
