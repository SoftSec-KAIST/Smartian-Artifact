.. spelling::

    harfbuzz

.. index:: unsorted ; harfbuzz

.. _pkg.harfbuzz:

harfbuzz
========

-  `Official <http://harfbuzz.org/>`__
-  `Hunterized <https://github.com/hunter-packages/harfbuzz>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/harfbuzz/CMakeLists.txt>`__
-  Added by `Jon Spencer <https://github.com/jhs67>`__ (`pr-1440 <https://github.com/ruslo/hunter/pull/1440>`__)

.. literalinclude:: /../examples/harfbuzz/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
