.. spelling::

    stdext

.. index:: unsorted ; stdext-path

.. _pkg.stdext-path:

stdext-path
===========

-  `Official GitHub <https://github.com/srand/stdext-path>`__
-  `Hunterized <https://github.com/hunter-packages/stdext-path>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/stdext-path/CMakeLists.txt>`__

.. literalinclude:: /../examples/stdext-path/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
