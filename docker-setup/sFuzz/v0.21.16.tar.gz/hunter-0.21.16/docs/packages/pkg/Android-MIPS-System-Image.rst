.. spelling::

    Android
    MIPS
    System
    Image

.. index:: android_sdk_component ; Android-MIPS-System-Image

.. _pkg.Android-MIPS-System-Image:

Android-MIPS-System-Image
=========================

-  `Example <https://github.com/ruslo/hunter/blob/master/examples/Android-MIPS-System-Image/CMakeLists.txt>`__

.. literalinclude:: /../examples/Android-MIPS-System-Image/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
