.. spelling::

    ncnn

.. index:: machine-learning ; ncnn

.. _pkg.ncnn:

ncnn
====
 
-  `Official <https://github.com/Tencent/ncnn>`__
-  `Hunterized <https://github.com/hunter-packages/ncnn>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/ncnn/CMakeLists.txt>`__

.. literalinclude:: /../examples/ncnn/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
