.. spelling::

    sqlite3

.. index:: database ; sqlite3

.. _pkg.sqlite3:

sqlite3
=======

-  https://www.sqlite.org
-  `Hunterized <https://github.com/hunter-packages/sqlite3>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/sqlite3/CMakeLists.txt>`__

.. literalinclude:: /../examples/sqlite3/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
