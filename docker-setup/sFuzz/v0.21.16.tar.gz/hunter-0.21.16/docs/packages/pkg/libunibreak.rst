.. spelling::

    libunibreak

.. index:: unsorted ; libunibreak

.. _pkg.libunibreak:

libunibreak
===========

-  `Official <https://github.com/adah1972/libunibreak>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/libunibreak/CMakeLists.txt>`__
-  Added by `Jon Spencer <https://github.com/jhs67>`__ (`pr-1443 <https://github.com/ruslo/hunter/pull/1443>`__)

.. literalinclude:: /../examples/libunibreak/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
