.. spelling::

    TCLAP

.. index:: commandline tools ; TCLAP

.. _pkg.TCLAP:

TCLAP
=====

-  `Official <http://tclap.sourceforge.net/>`__
-  `Hunterized <https://github.com/hunter-packages/tclap>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/TCLAP/CMakeLists.txt>`__
-  Added by `cyberunner23 <https://github.com/cyberunner23>`__ (`pr-1419 <https://github.com/ruslo/hunter/pull/1419>`__)

.. literalinclude:: /../examples/TCLAP/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }

