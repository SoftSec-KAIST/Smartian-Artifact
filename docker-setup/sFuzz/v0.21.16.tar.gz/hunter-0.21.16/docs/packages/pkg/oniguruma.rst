.. spelling::

    oniguruma

.. index:: regex ; oniguruma

.. _pkg.oniguruma:

oniguruma
=========

-  `Official <https://github.com/kkos/oniguruma>`__
-  `Hunterized <https://github.com/hunter-packages/oniguruma>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/oniguruma/CMakeLists.txt>`__
-  Added by `Isaac Hier <https://github.com/isaachier>`__ (`pr-1391 <https://github.com/ruslo/hunter/pull/1391>`__)

.. literalinclude:: /../examples/oniguruma/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
