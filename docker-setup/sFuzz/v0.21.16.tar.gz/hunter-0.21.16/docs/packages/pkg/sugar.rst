.. spelling::

    sugar

.. index:: cmake_modules ; sugar

.. _pkg.sugar:

sugar
=====

-  `Official GitHub <https://github.com/ruslo/sugar>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/sugar/CMakeLists.txt>`__

.. literalinclude:: /../examples/sugar/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
