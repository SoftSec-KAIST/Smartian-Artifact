.. spelling::

    android
    support
    repository
    packer

.. index:: android_sdk_component ; android_support_repository_packer

.. _pkg.android_support_repository_packer:

android_support_repository_packer
=================================

-  `Official <https://github.com/hunter-packages/android_support_repository_packer>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/android_support_repository_packer/CMakeLists.txt>`__

.. literalinclude:: /../examples/android_support_repository_packer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
