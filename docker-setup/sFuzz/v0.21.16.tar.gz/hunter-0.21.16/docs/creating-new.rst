.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Creating new package
--------------------

.. _creating new:

.. toctree::
   :maxdepth: 1

   /creating-new/create
   /creating-new/update
   /creating-new/patch
